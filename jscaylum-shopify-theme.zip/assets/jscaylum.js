(function () {
  'use strict';

  var config = window.jscaylumConfig || {};
  var ALBUM = config.album || null;
  var SIGNUP = config.signup || {};
  var IS_LOCAL_PREVIEW = ['localhost', '127.0.0.1', '::1'].includes(location.hostname);

  function formatCountdown(ms) {
    if (ms <= 0) return null;
    var totalSec = Math.floor(ms / 1000);
    var d = Math.floor(totalSec / 86400);
    var h = Math.floor((totalSec % 86400) / 3600);
    var m = Math.floor((totalSec % 3600) / 60);
    var s = totalSec % 60;
    if (d > 0) return d + 'd ' + h + 'h';
    if (h > 0) return h + 'h ' + m + 'm';
    if (m > 0) return m + 'm ' + s + 's';
    return s + 's';
  }

  // ------------------------------------------------------------------
  // nav scroll state + mobile menu
  // ------------------------------------------------------------------
  var header = document.getElementById('siteHeader');
  if (header) {
    window.addEventListener('scroll', function () {
      header.classList.toggle('scrolled', window.scrollY > 40);
    });
  }

  var menuBtn = document.getElementById('menuBtn');
  var navLinks = document.getElementById('navLinks');
  if (menuBtn && navLinks) {
    menuBtn.addEventListener('click', function () {
      var open = navLinks.classList.toggle('open');
      menuBtn.setAttribute('aria-expanded', open);
      menuBtn.textContent = open ? '✕' : '☰';
      if (header) header.classList.toggle('menu-open', open);
    });
    navLinks.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () {
        navLinks.classList.remove('open');
        menuBtn.setAttribute('aria-expanded', false);
        menuBtn.textContent = '☰';
        if (header) header.classList.remove('menu-open');
      });
    });
  }

  // ------------------------------------------------------------------
  // fetch real cover art from Spotify's public (keyless) oEmbed for any
  // cover that only has a Spotify link and no uploaded artwork image
  // ------------------------------------------------------------------
  document.querySelectorAll('.cover-img[data-spotify-url]').forEach(function (img) {
    var url = img.dataset.spotifyUrl;
    fetch('https://open.spotify.com/oembed?url=' + encodeURIComponent(url))
      .then(function (r) { if (!r.ok) throw new Error('bad response'); return r.json(); })
      .then(function (data) {
        if (!data.thumbnail_url) throw new Error('no artwork');
        img.src = data.thumbnail_url;
        img.addEventListener('load', function () { img.classList.add('loaded'); }, { once: true });
      })
      .catch(function () {
        var wrap = img.closest('.ep-art, .disco-art');
        if (wrap) wrap.classList.add('cover-fallback');
      });
  });

  // ------------------------------------------------------------------
  // track play buttons — highlight the track + draw attention to the
  // release card above
  // ------------------------------------------------------------------
  var trackPlayBtns = document.querySelectorAll('.track-play');
  var releaseCard = document.querySelector('.release');
  trackPlayBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      trackPlayBtns.forEach(function (b) { b.classList.remove('playing'); });
      document.querySelectorAll('.track').forEach(function (t) { t.classList.remove('flash'); });
      btn.classList.add('playing');
      var trackEl = btn.closest('.track');
      if (trackEl) trackEl.classList.add('flash');
      if (releaseCard) {
        releaseCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
        releaseCard.classList.add('pulse');
        setTimeout(function () { releaseCard.classList.remove('pulse'); }, 900);
      }
    });
  });

  // ------------------------------------------------------------------
  // scroll reveal
  // ------------------------------------------------------------------
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) { if (e.isIntersecting) e.target.classList.add('in'); });
  }, { threshold: 0.15 });
  document.querySelectorAll('.reveal').forEach(function (el) { io.observe(el); });

  // ------------------------------------------------------------------
  // about photo slideshow (images are already rendered by Liquid; this
  // just rotates which one is visible)
  // ------------------------------------------------------------------
  var aboutSlider = document.getElementById('aboutSlider');
  if (aboutSlider) {
    var slideEls = Array.prototype.slice.call(aboutSlider.querySelectorAll('.about-slide'));
    if (slideEls.length > 1) {
      var activeIndex = 0;
      setInterval(function () {
        activeIndex = (activeIndex + 1) % slideEls.length;
        slideEls.forEach(function (slide, index) {
          slide.classList.toggle('is-active', index === activeIndex);
        });
      }, 3000);
    }
  }

  // ------------------------------------------------------------------
  // featured release CTAs — prioritize Apple Music on Apple devices and
  // Spotify on Android
  // ------------------------------------------------------------------
  (function prioritizePlatformCta() {
    var ctaApple = document.getElementById('ctaApple');
    var ctaSpotify = document.getElementById('ctaSpotify');
    var ctas = document.getElementById('releaseCtas');
    if (!ctaApple || !ctaSpotify || !ctas) return;

    var ua = navigator.userAgent || navigator.vendor || '';
    var isAndroid = /android/i.test(ua);

    if (isAndroid) {
      ctaSpotify.classList.remove('btn-outline');
      ctaSpotify.classList.add('btn-primary');
      ctaApple.classList.remove('btn-primary');
      ctaApple.classList.add('btn-outline');
      ctas.insertBefore(ctaSpotify, ctaApple);
    }
  })();

  // ------------------------------------------------------------------
  // email signup
  // ------------------------------------------------------------------
  var signupForm = document.getElementById('signupForm');
  var formNote = document.getElementById('formNote');
  if (signupForm) {
    var defaultNote = formNote ? formNote.textContent : '';
    signupForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = signupForm.querySelector('button');
      var input = signupForm.querySelector('input[type="email"]');
      var email = input.value.trim();
      if (!email) return;

      btn.disabled = true;
      btn.textContent = 'sending...';
      if (formNote) formNote.textContent = defaultNote;

      var endpoint = SIGNUP.endpoint;
      var provider = SIGNUP.provider || 'formsubmit';

      if (!endpoint) {
        btn.disabled = false;
        btn.textContent = 'sign up';
        if (formNote) formNote.textContent = 'signup isn\u2019t connected yet \u2014 add an endpoint in theme settings.';
        return;
      }

      var isGoogleSheets = provider === 'googleSheets';
      var headers = isGoogleSheets
        ? { 'Content-Type': 'text/plain;charset=UTF-8' }
        : { 'Content-Type': 'application/json', 'Accept': 'application/json' };

      var payload;
      if (provider === 'mailchimp') {
        payload = { email_address: email, status: 'subscribed' };
      } else if (provider === 'convertkit') {
        payload = { api_key: SIGNUP.apiKey || '', email: email, first_name: '' };
      } else if (provider === 'formsubmit') {
        payload = { email: email, _subject: 'new site signup', _captcha: 'false', _template: 'table' };
      } else {
        payload = { email: email };
      }

      fetch(endpoint, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(payload),
        mode: isGoogleSheets ? 'no-cors' : undefined
      }).then(function (res) {
        if (!isGoogleSheets && res && !res.ok) throw new Error('request failed');
        btn.textContent = 'you\u2019re in';
        input.value = '';
        input.disabled = true;
        if (formNote) formNote.textContent = SIGNUP.successNote || 'you\u2019re on the list.';
      }).catch(function () {
        btn.disabled = false;
        btn.textContent = 'sign up';
        if (formNote) formNote.textContent = 'something went wrong \u2014 try again in a moment.';
      });
    });
  }

  // ------------------------------------------------------------------
  // "next era" countdown + tracklist reveal
  // ------------------------------------------------------------------
  if (!ALBUM) return;

  var REVEAL_DEADLINE = ALBUM.revealDeadline ? new Date(ALBUM.revealDeadline) : null;
  var RELEASE_DATE = ALBUM.releaseDate ? new Date(ALBUM.releaseDate) : null;
  var tracks = ALBUM.tracks || [];

  // schedule reveals: waterfall backward from REVEAL_DEADLINE in exact
  // 1-minute steps, so the last scheduled track lands exactly on it
  var scheduled = tracks.filter(function (t) { return !t.permanentlyRevealed; });
  if (REVEAL_DEADLINE) {
    scheduled.forEach(function (t, i) {
      var stepsFromEnd = (scheduled.length - 1) - i;
      t.revealAt = new Date(REVEAL_DEADLINE.getTime() - stepsFromEnd * 60000);
    });
  }
  var albumRevealTrack = scheduled.length ? scheduled[scheduled.length - 1] : null;

  function getPhase(now) {
    if (IS_LOCAL_PREVIEW) return 'release-countdown';
    if (REVEAL_DEADLINE && now < REVEAL_DEADLINE.getTime()) return 'reveal';
    if (RELEASE_DATE && now < RELEASE_DATE.getTime()) return 'release-countdown';
    return 'released';
  }

  var albumSubEl = document.getElementById('albumSub');
  var eyebrowEl = document.getElementById('countdownEyebrow');
  var albumTitleEl = document.getElementById('albumTitle');
  var countdownGridEl = document.getElementById('countdownGrid');
  var countdownGridUnits = countdownGridEl ? countdownGridEl.querySelectorAll('.countdown-unit .val') : null;
  var countdownCtaEl = document.getElementById('countdownCta');
  var trackRevealOverlay = document.getElementById('trackRevealOverlay');
  var trackRevealKickerEl = document.getElementById('trackRevealKicker');
  var trackRevealNameEl = document.getElementById('trackRevealName');
  var mysteryTracklistEl = document.getElementById('mysteryTracklist');

  function renderAlbumTitle() {
    if (!albumTitleEl || !ALBUM.name) return;
    var lower = ALBUM.name.toLowerCase();
    var splitAt = lower.lastIndexOf(' ');
    var firstPart = splitAt === -1 ? lower : lower.slice(0, splitAt);
    var lastWord = splitAt === -1 ? '' : lower.slice(splitAt + 1);
    albumTitleEl.innerHTML = lastWord
      ? firstPart + ' <em style="font-style:italic;color:var(--rose)">' + lastWord + '</em>'
      : '<em style="font-style:italic;color:var(--rose)">' + lower + '</em>';
  }
  renderAlbumTitle();

  function renderAlbumCtas() {
    if (!countdownCtaEl) return;
    var buttons = [
      { url: ALBUM.preSaveUrl, label: 'pre-save now', className: 'btn btn-primary lc' },
      { url: ALBUM.appleMusicUrl, label: 'apple music', className: 'btn btn-primary lc' },
      { url: ALBUM.spotifyUrl, label: 'spotify', className: 'btn btn-outline lc' }
    ].filter(function (item) { return item.url; });

    if (buttons.length) {
      countdownCtaEl.innerHTML = buttons.map(function (item) {
        return '<a href="' + item.url + '" target="_blank" rel="noopener" class="' + item.className + '">' + item.label + '</a>';
      }).join('');
      return;
    }
    countdownCtaEl.innerHTML = '<span class="album-cta-placeholder lc">links coming soon</span>';
  }

  function triggerTrackReveal(trackName, isAlbumReveal) {
    if (!trackRevealOverlay || !trackRevealNameEl || !trackName) return;
    if (RELEASE_DATE && Date.now() >= RELEASE_DATE.getTime()) return;

    if (trackRevealKickerEl) trackRevealKickerEl.textContent = isAlbumReveal ? 'album revealed' : 'new track';
    trackRevealNameEl.textContent = isAlbumReveal ? 'pre-save album' : trackName;
    trackRevealOverlay.classList.remove('is-visible');
    void trackRevealOverlay.offsetWidth;
    trackRevealOverlay.classList.add('is-visible');

    clearTimeout(triggerTrackReveal.timeoutId);
    triggerTrackReveal.timeoutId = setTimeout(function () {
      trackRevealOverlay.classList.remove('is-visible');
    }, 2400);
  }

  var trackRows = [];
  if (mysteryTracklistEl) {
    mysteryTracklistEl.setAttribute('aria-label', (ALBUM.name || '').toLowerCase() + ' tracklist, revealing gradually');
    tracks.forEach(function (t, i) {
      var num = String(i + 1).padStart(2, '0');
      var row = document.createElement('div');
      row.className = 'mystery-track';
      row.innerHTML = '<span class="track-num">' + num + '</span><span class="track-name">???</span><span class="track-countdown"></span>';
      mysteryTracklistEl.appendChild(row);
      trackRows.push({
        track: t,
        nameEl: row.querySelector('.track-name'),
        countdownEl: row.querySelector('.track-countdown'),
        revealedShown: false
      });
    });
  }

  function renderTracklist() {
    var now = Date.now();
    trackRows.forEach(function (r) {
      var t = r.track;
      var isRevealed = IS_LOCAL_PREVIEW || t.permanentlyRevealed || (t.revealAt && now >= t.revealAt.getTime());

      if (isRevealed) {
        if (!r.revealedShown) {
          var trackName = t.name || 'untitled';
          r.nameEl.textContent = trackName;
          r.nameEl.classList.add('revealed', 'glow');
          r.countdownEl.classList.add('fade-out');
          r.revealedShown = true;
          triggerTrackReveal(trackName, t === albumRevealTrack);
          r.nameEl.addEventListener('animationend', function () {
            r.nameEl.classList.remove('glow');
          }, { once: true });
        }
      } else {
        var countdown = t.revealAt ? formatCountdown(t.revealAt.getTime() - now) : null;
        r.countdownEl.textContent = countdown ? 'reveals in ' + countdown : '';
      }
    });
  }

  var lastPhase = null;
  function renderPhase() {
    var now = Date.now();
    var phase = getPhase(now);

    if (phase !== lastPhase) {
      lastPhase = phase;
      if (phase === 'reveal') {
        if (eyebrowEl) eyebrowEl.textContent = 'next up \u00b7 unannounced';
        if (albumSubEl) albumSubEl.textContent = ALBUM.tagline || '';
        renderAlbumTitle();
        if (countdownGridEl) countdownGridEl.hidden = false;
        if (mysteryTracklistEl) mysteryTracklistEl.hidden = false;
        if (countdownCtaEl) countdownCtaEl.innerHTML = '<a href="#tour" class="btn btn-primary lc">get notified</a>';
      } else if (phase === 'release-countdown') {
        if (eyebrowEl) eyebrowEl.textContent = ALBUM.comingLabel || 'coming soon';
        if (albumSubEl) albumSubEl.textContent = ALBUM.releaseSub || '';
        renderAlbumTitle();
        if (countdownGridEl) countdownGridEl.hidden = false;
        if (mysteryTracklistEl) mysteryTracklistEl.hidden = false;
        renderAlbumCtas();
      } else {
        if (eyebrowEl) eyebrowEl.textContent = 'nothing announced currently';
        if (albumSubEl) albumSubEl.textContent = 'new music coming soon.';
        if (albumTitleEl) albumTitleEl.textContent = 'coming soon';
        if (countdownGridEl) countdownGridEl.hidden = true;
        if (mysteryTracklistEl) mysteryTracklistEl.hidden = true;
        if (countdownCtaEl) countdownCtaEl.innerHTML = '';
        if (trackRevealOverlay) trackRevealOverlay.classList.remove('is-visible');
      }
    }

    var target = phase === 'reveal' ? REVEAL_DEADLINE : RELEASE_DATE;
    if (countdownGridUnits && target) {
      var ms = target.getTime() - now;
      if (ms <= 0) {
        countdownGridUnits.forEach(function (u) { u.textContent = '00'; });
      } else {
        var totalSec = Math.floor(ms / 1000);
        var d = Math.floor(totalSec / 86400);
        var h = Math.floor((totalSec % 86400) / 3600);
        var m = Math.floor((totalSec % 3600) / 60);
        var s = totalSec % 60;
        [d, h, m, s].forEach(function (v, i) {
          if (countdownGridUnits[i]) countdownGridUnits[i].textContent = String(v).padStart(2, '0');
        });
      }
    }
  }

  renderPhase();
  renderTracklist();
  setInterval(function () { renderPhase(); renderTracklist(); }, 1000);
})();
